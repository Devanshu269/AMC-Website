// window.onload = function(){}
var firebaseConfig = {
    apiKey: "AIzaSyAdWq4-ZE4Yv87w_AEyy5b5JwkW9A8iL3U",
    authDomain: "contact-form-38b0b.firebaseapp.com",
    databaseURL: "https://contact-form-38b0b-default-rtdb.firebaseio.com",
    projectId: "contact-form-38b0b",
    storageBucket: "contact-form-38b0b.appspot.com",
    messagingSenderId: "748179068137",
    appId: "1:748179068137:web:2a3ad3ed4d8a07ac990c78",
    measurementId: "G-HC8E0ED0TD"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
$(document).ready(function() {
    let dataSet
    let USN
    let Name
    let Student_Section
    let sub1, sub2, sub3, sub4, sub5, sub6, sub7, sub8, sub9


    var table = $('#user_data').DataTable({
        data: dataSet,
        columns: [
            { data: USN, title: 'USN' },
            { data: Name, title: 'Name' },
            { data: Student_Section, title: 'Section'},
            { data: sub1, title: 'Analog and Digital Electronics' },
            { data: sub2, title: 'Additional Mathematics I' },
            { data: sub3, title: 'Computer Organization' },
            { data: sub4, title: 'Constitution of India' },
            { data: sub5, title: 'Data Structures and Applications' },
            { data: sub6, title: 'Discrete Mathematical Structures' },
            { data: sub7, title: 'Analog and Digital Electronics Laboratory' },
            { data: sub8, title: 'Software Engineering' },
            { data: sub9, title: 'Transform Calculus' },
        ],
        dom: 'Bfrtip',
        orderCellsTop: true,
        fixedHeader: true,
        targets: -1,
        className: 'dt-body-right',
        responsive: true,
        hover: 1,
        // select: {
        //     style: 'os',
        //     selector: 'td:first-child'
        // },
        buttons: [

            'excel', 'pdf', 'print'
        ]

    });
    firebase.database().ref('Result/Sem3/CSE/IA1').on('child_added', function(snapshot) {
        dataSet = [USN = snapshot.val().USN, Name = snapshot.val().Name, Student_Section = snapshot.val().Section, sub1 = snapshot.val().Analog_and_Digital_Electronics,
            sub2 = snapshot.val().Additional_Mathematics_I,sub3 = snapshot.val().Computer_Organization,
            sub4 = snapshot.val().Constitution_of_India,sub5 = snapshot.val().Data_Structures_and_Applications,
            sub6 = snapshot.val().Discrete_Mathematical_Structures,sub7 = snapshot.val().Analog_and_Digital_Electronics_Laboratory,
            sub8 = snapshot.val().Software_Engineering, sub9 = snapshot.val().Transform_Calculus,];
        table.rows.add([dataSet]).draw();
    });
 

});
$(document).ready(function() {
    let dataSet
    let USN
    let Name
    let Student_Section
    let sub1, sub2, sub3, sub4, sub5, sub6, sub7, sub8, sub9

    var table = $('#user_data2').DataTable({
        data: dataSet,
        columns: [
            { data: USN, title: 'USN' },
            { data: Name, title: 'Name' },
            { data: Student_Section, title: 'Section'},
            { data: sub1, title: 'Analog and Digital Electronics' },
            { data: sub2, title: 'Additional Mathematics I' },
            { data: sub3, title: 'Computer Organization' },
            { data: sub4, title: 'Constitution of India' },
            { data: sub5, title: 'Data Structures and Applications' },
            { data: sub6, title: 'Discrete Mathematical Structures' },
            { data: sub7, title: 'Analog and Digital Electronics Laboratory' },
            { data: sub8, title: 'Software Engineering' },
            { data: sub9, title: 'Transform Calculus' },
        ],
        dom: 'Bfrtip',
        orderCellsTop: true,
        fixedHeader: true,
        targets: -1,
        className: 'dt-body-right',
        responsive: true,
        hover: 1,
        // select: {
        //     style: 'os',
        //     selector: 'td:first-child'
        // },
        buttons: [

            'excel', 'pdf', 'print'
        ]

    });
    firebase.database().ref('Result/Sem3/CSE/IA2').on('child_added', function(snapshot) {
        dataSet = [USN = snapshot.val().USN, Name = snapshot.val().Name, Student_Section = snapshot.val().Section, sub1 = snapshot.val().Analog_and_Digital_Electronics,
            sub2 = snapshot.val().Additional_Mathematics_I,sub3 = snapshot.val().Computer_Organization,
            sub4 = snapshot.val().Constitution_of_India,sub5 = snapshot.val().Data_Structures_and_Applications,
            sub6 = snapshot.val().Discrete_Mathematical_Structures,sub7 = snapshot.val().Analog_and_Digital_Electronics_Laboratory,
            sub8 = snapshot.val().Software_Engineering, sub9 = snapshot.val().Transform_Calculus,];
        table.rows.add([dataSet]).draw();
    });
 

});
$(document).ready(function() {
    let dataSet
    let USN
    let Name
    let Student_Section
    let sub1, sub2, sub3, sub4, sub5, sub6, sub7, sub8, sub9

    var table = $('#user_data3').DataTable({
        data: dataSet,
        columns: [
            { data: USN, title: 'USN' },
            { data: Name, title: 'Name' },
            { data: Student_Section, title: 'Section'},
            { data: sub1, title: 'Analog and Digital Electronics' },
            { data: sub2, title: 'Additional Mathematics I' },
            { data: sub3, title: 'Computer Organization' },
            { data: sub4, title: 'Constitution of India' },
            { data: sub5, title: 'Data Structures and Applications' },
            { data: sub6, title: 'Discrete Mathematical Structures' },
            { data: sub7, title: 'Analog and Digital Electronics Laboratory' },
            { data: sub8, title: 'Software Engineering' },
            { data: sub9, title: 'Transform Calculus' },
        ],
        dom: 'Bfrtip',
        orderCellsTop: true,
        fixedHeader: true,
        targets: -1,
        className: 'dt-body-right',
        responsive: true,
        hover: 1,
        // select: {
        //     style: 'os',
        //     selector: 'td:first-child'
        // },
        buttons: [

            'excel', 'pdf', 'print'
        ]

    });
    firebase.database().ref('Result/Sem3/CSE/IA3').on('child_added', function(snapshot) {
        dataSet = [USN = snapshot.val().USN, Name = snapshot.val().Name, Student_Section = snapshot.val().Section, sub1 = snapshot.val().Analog_and_Digital_Electronics,
            sub2 = snapshot.val().Additional_Mathematics_I,sub3 = snapshot.val().Computer_Organization,
            sub4 = snapshot.val().Constitution_of_India,sub5 = snapshot.val().Data_Structures_and_Applications,
            sub6 = snapshot.val().Discrete_Mathematical_Structures,sub7 = snapshot.val().Analog_and_Digital_Electronics_Laboratory,
            sub8 = snapshot.val().Software_Engineering, sub9 = snapshot.val().Transform_Calculus, ];
        table.rows.add([dataSet]).draw();
    });
 

});



